# cve_fetcher.py
import requests
import datetime


def fetch_latest_cves():
    # Aktualny endpoint NVD API v2.0
    url = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    # Używamy timezone-aware daty w UTC
    end_date = datetime.datetime.now(datetime.timezone.utc)
    start_date = end_date - datetime.timedelta(days=7)
    params = {
        "pubStartDate": start_date.isoformat(),
        "pubEndDate": end_date.isoformat(),
        "resultsPerPage": 20  # Możesz zmienić w razie potrzeby
    }

    response = requests.get(url, params=params)
    if response.status_code == 200:
        data = response.json()
        # W API v2.0 dane o podatnościach znajdują się pod kluczem "vulnerabilities"
        cve_items = data.get("vulnerabilities", [])
        return cve_items
    else:
        print("Błąd pobierania danych:", response.status_code)
        return []


if __name__ == "__main__":
    cves = fetch_latest_cves()
    print(f"Pobrano {len(cves)} rekordów CVE")
