# report_generator.py
from jinja2 import Environment, FileSystemLoader
import os


def generate_report(cve_data, scan_results, output_file="report.html"):
    # Przygotuj środowisko Jinja2 – zakładając, że szablon znajduje się w folderze 'templates'
    env = Environment(loader=FileSystemLoader('templates'))
    template = env.get_template('report_template.html')

    # Renderuj szablon z danymi
    rendered_report = template.render(cve_data=cve_data, scan_results=scan_results)

    # Zapisz raport do pliku
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(rendered_report)
    print(f"Raport zapisany do {output_file}")


if __name__ == "__main__":
    # Przykładowe dane do testów
    example_cve = [{"cve": "CVE-2021-1234", "description": "Przykładowa podatność"}]
    example_scan = {"nginx": "1.18.0", "openssl": "1.1.1"}
    generate_report(example_cve, example_scan)
