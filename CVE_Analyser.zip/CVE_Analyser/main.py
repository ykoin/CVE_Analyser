import time
import schedule
from cve_fetcher import fetch_latest_cves
from vulnerability_scanner import scan_system
from report_generator import generate_report

def run_analysis():
    print("Rozpoczynam analizę...")
    cve_data = fetch_latest_cves()
    scan_results = scan_system()
    generate_report(cve_data, scan_results)
    print("Analiza zakończona.")

if __name__ == "__main__":
    run_analysis()  # Uruchomienie analizy od razu przy starcie
    # Harmonogram: co 24 godziny
    schedule.every(24).hours.do(run_analysis)
    while True:
        schedule.run_pending()
        time.sleep(60)
